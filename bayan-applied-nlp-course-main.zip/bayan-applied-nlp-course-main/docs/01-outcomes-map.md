# مصفوفة الأهداف والأدلة | Outcomes-to-Evidence Map

هذه المصفوفة تمنع وجود شرح بلا تطبيق أو تطبيق بلا تقييم. كل هدف رسمي مرتبط بدرس، مختبر، مخرج في مشروع **بيان**، ودليل داخل مستودع المتدرب.

| # | الهدف | اليوم/الوحدة | التطبيق الإلزامي | مخرج بيان | دليل الاجتياز |
|---:|---|---|---|---|---|
| 1 | معالجة النصوص والترميز، ومنها العربية | يوم 1: M1؛ [يوم 3: M4](../day-03/01-arabic-nlp-camel-tools.md) | Unicode، regex، masking، tokenizer fertility، normalisation profiles | `src/bayan/preprocessing.py` + `arabic_profiles.py` | اختبارات ذهبية + قرار tokenizer/profile |
| 2 | شرح الانتباه والمحولات | يوم 1: M2 | حساب attention صغير، تتبع shapes، ثم forward pass فعلي وعدّ المعاملات وقراءة رؤوس attention | notebook يشرح forward pass | asserts عددية + تفسير خريطة attention وحدودها |
| 3 | Fine-tuning للتصنيف وNER وQA | [يوم 2: M3](../day-02/README.md) | baseline ثم نموذج BERT-family؛ label alignment؛ null answer | `03_text_classification.ipynb` + `04_ner_and_qa.ipynb` | metrics موسومة + zero leakage + اختبارات alignment/no-answer |
| 4 | البحث الدلالي بالتضمينات | [يوم 3: M5](../day-03/02-semantic-search.md) | bi-encoder، cosine، FAISS، ثم cross-encoder re-ranking مقاس | bilingual case search | Recall@k وMRR + اختبار cross-lingual + فرق الجودة/الزمن |
| 5 | التقييم وتحليل الأخطاء | [يوم 3: M6](../day-03/03-evaluation-error-analysis.md) | task metrics، slices، CIs، behavioural tests، taxonomy | `EVALUATION_REPORT.md` وmodel cards | نتائج قابلة لإعادة الإنتاج + 3 إصلاحات مرتبة |
| 6 | تحسين الاستدلال والذاكرة | [يوم 4: M7](../day-04/README.md) | batching/length، ONNX، INT8 حيث يدعم، benchmark منضبط | optimized serving path | latency/memory/quality tax قبل وبعد |
| تكامل | مشروع عربي/إنجليزي مكتمل | [الأيام 1–4](../day-04/04-capstone-assembly-demo.md) | تجميع LO1–LO6، API، README، demo، وامتداد واحد مقاس | مستودع Bayan عام | [validator + rubric + tag](../day-04/05-lab-gates-submission.md) `submission-v1.0` |

## التدرّج حسب المستوى | Level differentiation

| المسار | ما ينجزه | معيار النجاح |
|---|---|---|
| 🟢 أساسي | خلايا TODO المحددة، البيانات المصغرة، نموذج صغير، retrieve ثم re-rank مقاس، وتقارير القالب | جميع الأدلة الإلزامية تعمل وتُشرح |
| 🔵 استكشاف | مقارنة إعدادين، slice إضافي، أو ضبط عدد مرشحي re-ranking | قرار تقني مدعوم بقياس |
| 🟣 تميّز | Arabizi، drift، ANN scale، أو ضبط/استبدال cross-encoder | إضافة مستقلة لا تكسر المسار الأساسي |

> مسارات المستوى أعلاه تخص عمل المختبرات. R7 في المشروع يتطلب امتدادًا واحدًا مقاسًا للجميع؛ مهام التميّز الإضافية هي وحدها optional enrichment.

## تغطية القياس | Assessment coverage

| المعايير / Criteria | Outcomes | Points |
|---|---|---:|
| T1 | LO1 | 12 |
| T2 | LO2 | 6 |
| T3 | LO3, LO5 | 18 |
| T4 | LO4, LO5 | 10 |
| T5 | LO5 | 10 |
| T6 | LO6 | 10 |
| T7 | measured extension / integration | 4 |
| A1–A5 | documentation, evidence and submission | 20 |
| P1–P5 | individual demonstration and understanding | 10 |
| **Total** | **six scientific outcomes retained** | **100** |

[التفاصيل ودرجات كل بند](policies/assessment-and-completion.md). الأدلة هي أساس التصحيح؛ لا يمنح ذكر الهدف وحده نقاطًا. المواد التدريبية PA والاختبار القصير للممارسة، ولا توجد لها أوزان مستقلة في هذا الإصدار.
